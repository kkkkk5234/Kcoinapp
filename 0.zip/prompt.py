import webview
import os
import sys

def resource_path(relative_path):
    """ Hàm để xác định đường dẫn tài liệu khi đóng gói EXE """
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)

class API:
    def hello_from_js(self, msg):
        print(f"JS gửi: {msg}")
        webview.active_window().create_confirmation_dialog("Thông báo", "Python đã nhận được tin!")

if __name__ == '__main__':
    api = API()
    # Trỏ đến file HTML đã tạo
    html_file = resource_path("index.html")
    
    window = webview.create_window('Phần mềm của tôi', html_file, js_api=api)
    webview.start()
