from .core import BaseMax

__all__ = ["BaseMax"]