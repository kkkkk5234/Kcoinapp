class BaseMax:

    key = 3

    _encode_map = {
        "A": "࿐࿑", "B": "๛༈", "C": "ཉ࿑ༀ ", "D": "མ༃",
        "E": "རѬ", "F": "ཏϩϪ", "G": "ཡƾѨ", "H": "ྋཝཨ",
        "I": "ཞླжй", "J": "ཇҸ", "K": "པ౨", "L": "ལ╦̵̵͇̿̿̿̿",
        "M": "ཀ╦", "N": "ཤปๅ", "O": "ཧะ ั ", "P": "གᶩ ์ ๎",
        "Q": "ངصأن", "R": "དس", "S": "لالفص", "T": "འأوقية",
        "U": "ཟ", "V": "ཛ", "W": "ཅ", "X": "ཙ",
        "Y": "བ", "Z": "ན",
        " ": "¤"
    }

    _decode_map = {v: k for k, v in _encode_map.items()}

    @classmethod
    def encode(cls, text):
        text = text.upper()
        step1 = "".join(cls._encode_map.get(c, c) for c in text)
        step2 = step1[::-1]
        step3 = "".join(chr(ord(c) + cls.key) for c in step2)
        return "☯" + "༒".join(step3) + "☯"

    @classmethod
    def decode(cls, text):
        text = text.strip("☯")
        parts = text.split("༒")
        step1 = "".join(chr(ord(c) - cls.key) for c in parts)
        step2 = step1[::-1]

        result = step2
        for k, v in cls._decode_map.items():
            result = result.replace(k, v)

        return result